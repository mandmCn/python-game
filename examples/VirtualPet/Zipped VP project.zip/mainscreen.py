#!/usr/bin/python

"""
__version__ = "$Revision: 1.5 $"
__date__ = "$Date: 2004/04/30 16:26:12 $"
"""

from PythonCard import model, timer, dialog
import pickle, datetime, wx
class MyBackground(model.Background):

    def on_initialize(self, event):
        self.myTimer1 = timer.Timer(self.components.petwindow, -1) # create a timer
        self.myTimer1.Start(500) # launch timer, to fire every 500ms (0.5 seconds)
        self.myTimer2 = timer.Timer(self.components.Hugauge, -1) # create a timer
        self.myTimer2.Start(5000) # launch timer, to fire every 5000ms (5 seconds)
        self.doctor = False
        self.walk = False
        self.sleeping = False
        filehandle = True
        try:
            file = open("savedata_vp.pkl", "r")
        except:
            filehandle = False
        if filehandle:
            save_list = pickle.load(file)
            file.close
        else:
            save_list = [8, 8, 8, datetime.datetime.now(), False]
        self.components.HaGauge.value = save_list[0]
        self.components.HeGauge.value = save_list[1]
        self.components.Hugauge.value = save_list[2]
        then = save_list[3]
        self.sleeping = save_list[4]
        if self.sleeping:
            self.components.petwindow.file = "slp1.gif"
        difference = datetime.datetime.now() - then
        minutes = difference.seconds / 60
        for lower_stat in range(0, minutes):
            if lower_stat % 60 == 0:
                if self.components.Hugauge.value > 0:
                    self.components.Hugauge.value -= 1
                elif self.components.HeGauge.value > 0:
                    self.components.HeGauge.value -= 1
            if lower_stat % 30 == 0:
                if self.components.HaGauge.value > 0:
                    self.components.HaGauge.value -= 1
        self.forceawake = False
    def sleep_test(self):
        if self.sleeping:
            result = dialog.messageDialog(self, 'WARNING!\nYour pet is sleeping, if you wake him up he\'ll be unhappy!\nDo you want to proceed?', 'WARNING!', wx.ICON_EXCLAMATION | wx.YES_NO | wx.NO_DEFAULT)
            if result.accepted:
                self.sleeping = False
                self.components.HaGauge.value = 2
                self.forceawake = True
                return True
            else:
                return False
        else:
            return True

    def on_doctor_mouseClick(self, event):
        if self.sleep_test():        
            #start "doctor" animation
            self.components.petwindow.file = "doc1.gif"
            self.doctor = True
    def on_feed_mouseClick(self, event):
        if self.sleep_test():
            if self.components.Hugauge.value < 8:
                #feed pet
                self.components.Hugauge.value += 2
                self.doctor = False
                #change pic to feeding pic
                self.components.petwindow.file = "petf.gif"
                self.forceawake = False
    def on_play_mouseClick(self, event):
        if self.sleep_test():
            self.components.petwindow.file = "ply1.gif"
            self.walk = True
    def on_walk_mouseClick(self, event):
        if self.sleep_test():
            self.components.petwindow.file = "wok1.gif"
            self.walk = True
    def on_petwindow_timer(self, event):
        if self.components.petwindow.file[-5:] == "1.gif":
            self.components.petwindow.file = self.components.petwindow.file[0:3] + "2.gif"
        else:
            self.components.petwindow.file = self.components.petwindow.file[0:3] + "1.gif"

    def on_Hugauge_timer(self, event):
        if self.doctor:
            if self.components.HeGauge.value < 8:
                self.components.HeGauge.value += 1
            else:
                self.doctor = False
                self.forceawake = False
                self.components.petwindow.file = "pet1.gif"
        elif self.walk:
            if self.components.HeGauge.value < 8:
                self.components.HeGauge.value += 3
            if self.components.HaGauge.value < 8:
                self.components.HaGauge.value += 5
            if self.components.HaGauge.value == 8 and self.components.HeGauge.value == 8:
                self.walk = False
                self.components.petwindow.file = "pet1.gif"
                self.forceawake = False
        if not self.doctor and not self.sleeping:
            if self.components.Hugauge.value >0:
                self.components.Hugauge.value -= 1
            else:
                if self.components.HeGauge.value >0:
                    self.components.HeGauge.value -= 2
            if self.components.Hugauge.value <3:
                if self.components.HaGauge.value >0:
                    self.components.HaGauge.value -=2
        if 10 >= datetime.datetime.now().hour or datetime.datetime.now().hour >= 20:
            if not self.forceawake:
                self.sleeping = True
                self.components.petwindow.file = "slp1.gif"
    def on_close(self, event):
        file = open("savedata_vp.pkl", "w")
        save_list = [self.components.HaGauge.value, self.components.HeGauge.value, self.components.Hugauge.value, datetime.datetime.now(), self.sleeping]
        pickle.dump(save_list, file)
        event.Skip()
if __name__ == '__main__':
    app = model.Application(MyBackground)
    app.MainLoop()